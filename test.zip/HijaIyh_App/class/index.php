<?php 
/** HijaIyh App Framework
* @author justalinko
* @version 2.1
**/