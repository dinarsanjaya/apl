how to use?
1. first before install, edit all of ur setting at : HijaIyh_App -> class -> hiapi.iyh.php
2. save hiapi.iyh.php after edit, and then install
*account key : DNTHIRTEEN-KEY-L34KC0DE
*api key : DNTHIRTEEN-API-H34RTBL33D-L34KC0DE